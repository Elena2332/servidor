package servlets;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.Cliente;
import dao.ClienteDAO;
import dao.PedidoDAO;

/**
 * Servlet implementation class ServletLogin
 */
@WebServlet("/ServletLogin")
public class ServletLogin extends HttpServlet {
	private ClienteDAO bdCliente;
	private PedidoDAO bdPedido;
    
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        bdCliente = new ClienteDAO();
        bdPedido = new PedidoDAO();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doGet(request, response);
		
		HttpSession session = request.getSession(false);
		String mensajeError = "";
		
		if (session == null) {
			session = request.getSession(true);
		} else {
			session.invalidate();
			session = request.getSession(true);
		}
		
		if (request.getParameter("login") != null) {
			String usuario = request.getParameter("usuario");
			String pass = request.getParameter("pass");
			
			if (usuario.equals("") || pass.equals("")) {
				response.sendRedirect("login.jsp");
			} else {
				Cliente cliente = bdCliente.buscaCliente(usuario, pass);
				
				if (cliente == null) {
					mensajeError = "No se encuentra en la Base de Datos";
					request.setAttribute("mensajeError", mensajeError);
					request.getRequestDispatcher("login.jsp").forward(request, response);
				} else {
					request.getSession().setAttribute("cliente", cliente);
					request.getSession().setAttribute("listaItems", bdPedido.todosItems());
					request.getRequestDispatcher("tienda.jsp").forward(request, response);
				}
				
			}			
		}
		
		
	}

}
