package beans;

import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class CarroCompra {

	private HashMap<Integer, LineaPedido> carro = new HashMap<Integer, LineaPedido>();
	
	/*
	 * A�ade la l�nea de pedido al �carro�. Si corresponde a un item que ya exist�a en el carro, se sumar�
	 * la cantidad en la Linea ya existente. (Recuerda que el �carro� tiene como claves los id�s de los items)
	 */
	public void aniadeLinea (LineaPedido linea) {
		int idItem = linea.getItem().getIdItem();
		if (carro.containsKey(idItem)) {
			LineaPedido lineaPedido = carro.get(idItem);
			lineaPedido.setCantidad(lineaPedido.getCantidad() + linea.getCantidad());
		} else {
			carro.put(linea.getItem().getIdItem(), linea);
		}
	}
	
	public void borraLinea(int idItem) {
		carro.remove(idItem);
	}
	
	public LineaPedido getLineaPedido(int idItem) {
		return carro.get(idItem);
	}
	
	public Collection<LineaPedido> getLineasPedido() {
		return null;
	}
	
	// Devuelve el precio total actual del carro
	public double total() {
		double importeTotal = 0;
		Set<Integer> keys = carro.keySet();
		for (Integer key : keys) {
			importeTotal += (carro.get(key).getCantidad() * carro.get(key).getItem().getPrecio());
		}
		
		return importeTotal;
	}
	
	// Vac�a el carro
	public void removeAll() {
		carro.clear();
	}
	
	// Devuelve si el carro est� vac�o o no
	public boolean vacio() {
		if (carro.size() == 0) {
			return true;
		} else {
			return false;
		}
	}

	public HashMap<Integer, LineaPedido> getCarro() {
		return carro;
	}

	public void setCarro(HashMap<Integer, LineaPedido> carro) {
		this.carro = carro;
	}
	
}
