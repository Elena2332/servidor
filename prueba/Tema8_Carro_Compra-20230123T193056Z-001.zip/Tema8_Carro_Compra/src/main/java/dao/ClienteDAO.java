package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import beans.Cliente;

public class ClienteDAO {
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/tienda?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String USER = "root";
    private static final String PASS = "";
    private static BasicDataSource dataSource;

    public ClienteDAO() {
        //Creamos el pool de conexiones
        dataSource = new BasicDataSource();
        dataSource.setDriverClassName(DRIVER);
        dataSource.setUrl(URL);
        dataSource.setUsername(USER);
        dataSource.setPassword(PASS);
        //Indicamos el tama�o del pool de conexiones
        dataSource.setInitialSize(50);
    }

	/*
	 * Busca en la BD el cliente con el nombre de usuario y password recibidos como par�metros y lo
	 * devuelve como Cliente (null si no existe)
	 */
	public Cliente buscaCliente(String nombre, String password) {
		Cliente cliente = null;
		String sql = "SELECT * FROM clientes WHERE nombre='" + nombre + "' AND password='" + password + "'";
		try {
            Connection con = dataSource.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if(rs.next()){
                cliente = new Cliente(rs.getInt("id"), rs.getString("nombre"), rs.getString("password"), rs.getString("domicilio"), rs.getString("codigopostal"), rs.getString("telefono"), rs.getString("email"));
            }
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
		
		return cliente;
	}
	
	//Devuelve si existe o no un cliente con el nombre indicado.
	public boolean buscaCliente(String nombre) {
		boolean existeCliente = false;
		String sql = "SELECT * FROM clientes WHERE nombre='" + nombre + "'";
		try {
            Connection con = dataSource.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            if(rs.next()){
                existeCliente = true;
            }
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

		return existeCliente;
	}
	
	/*
	 * Guarda un nuevo cliente en la BD, con la informaci�n del par�metro. Devuelve si la operaci�n
	 * ha tenido �xito
	 */
	public boolean guardaCliente(Cliente cliente) {
		boolean exitoProceso = false;
		int id = -1;
		String sql = "INSERT INTO clientes(id, nombre, password, domicilio, codigopostal, telefono, email) "
                + " VALUES(?, ?, ?, ?, ?, ?, ?)";
        try {
            Connection con = dataSource.getConnection();
            PreparedStatement st = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            st.setInt(1, cliente.getIdCliente());
            st.setString(2, cliente.getNombre());
            st.setString(3, cliente.getPassword());
            st.setString(4, cliente.getDomicilio());
            st.setString(5, cliente.getCodigoPostal());
            st.setString(6, cliente.getTelefono());
            st.setString(7, cliente.getEmail());
            
            st.executeUpdate();
            
            ResultSet rs = st.getGeneratedKeys();
            if(rs.next()){
                id = rs.getInt(1);
                exitoProceso = true;
            }
            
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            System.err.println("Error en metodo insertarAutor: " + ex);
        }
		
		return exitoProceso;
	}
	
	/*
	 * Actualiza un cliente en la BD, con la informaci�n del par�metro. Devuelve si la operaci�n
	 * ha tenido �xito
	 */
	public boolean actualizaCliente(Cliente cliente) {
		boolean exitoProceso = false;
		String sql = "UPDATE clientes SET id=?, nombre=?, password=?, domicilio=?, codigopostal=?, telefono=?, email=? WHERE id=?";
        try {
            Connection con = dataSource.getConnection();
            PreparedStatement st = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            st.setInt(1, cliente.getIdCliente());
            st.setString(2, cliente.getNombre());
            st.setString(3, cliente.getPassword());
            st.setString(4, cliente.getDomicilio());
            st.setString(5, cliente.getCodigoPostal());
            st.setString(6, cliente.getTelefono());
            st.setString(7, cliente.getEmail());
            st.setInt(8, cliente.getIdCliente());
            
            st.executeUpdate();
            
            ResultSet rs = st.getGeneratedKeys();
            if(rs.next()){
                exitoProceso = true;
            }
            
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            System.err.println("Error en metodo actualizaCliente: " + ex);
        }
		
		return exitoProceso;
	}
	
}
