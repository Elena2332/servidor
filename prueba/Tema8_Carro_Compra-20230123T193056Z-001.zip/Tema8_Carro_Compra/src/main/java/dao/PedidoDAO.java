package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import beans.Cliente;
import beans.Item;
import beans.LineaPedido;
import beans.Pedido;

public class PedidoDAO {
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/tienda?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String USER = "root";
    private static final String PASS = "";
    private static BasicDataSource dataSource;

    public PedidoDAO() {
        //Creamos el pool de conexiones
        dataSource = new BasicDataSource();
        dataSource.setDriverClassName(DRIVER);
        dataSource.setUrl(URL);
        dataSource.setUsername(USER);
        dataSource.setPassword(PASS);
        //Indicamos el tama�o del pool de conexiones
        dataSource.setInitialSize(50);
    }
    
	// Devuelve un HashMap con todos los �tems en venta de la base de datos
	public HashMap<Integer, Item> todosItems() {
		HashMap<Integer, Item> listaItems = new HashMap<Integer, Item>();
		String sql = "SELECT * FROM items";
		try {
            Connection con = dataSource.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                Item item = new Item(rs.getInt("id"), rs.getString("nombre"), rs.getDouble("precio"));
                listaItems.put(rs.getInt("id"), item);
            }
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
				
		return listaItems;
	}
	
	// Devuelve el item cuyo id se recibe como par�metro o null
	public Item buscaItemPorId(int idItem) {
		Item item = null;
		String sql = "SELECT * FROM items WHERE id=" + idItem;
		try {
            Connection con = dataSource.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                item = new Item(rs.getInt("id"), rs.getString("nombre"), rs.getDouble("precio"));
            }
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
		
		return item;
	}
	
	// Recibe un pedido y lo almacena en la bd
	public void guardaPedido(Pedido pedido) {
		String sql = "INSERT INTO pedidos(id, total, fecha, idcliente) VALUES(?, ?, ?, ?)";
        try {
            Connection con = dataSource.getConnection();
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, pedido.getIdPedido());
            st.setDouble(2, pedido.getImporteTotal());
            SimpleDateFormat formateador = new SimpleDateFormat("yyyy-MM-dd");
            String fechastr = formateador.format(pedido.getFecha());
            st.setString(3, fechastr);
            st.setInt(4, pedido.getCliente().getIdCliente());
            
            st.executeUpdate();

            st.close();
            con.close();
        } catch (SQLException ex) {
            System.err.println("Error en metodo guardaPedido: " + ex);
        }
	}
	
	// Recibe una l�nea de pedido y la almacena en la bd
	public void guardaLineaPedido(LineaPedido lineaPedido) {
		String sql = "INSERT INTO lineaspedido(id, cantidad, idpedido, iditem) VALUES(?, ?, ?, ?)";
        try {
            Connection con = dataSource.getConnection();
            PreparedStatement st = con.prepareStatement(sql);
            st.setInt(1, lineaPedido.getIdLineaPedido());
            st.setInt(2, lineaPedido.getCantidad());
            st.setInt(3, lineaPedido.getPedido().getIdPedido());
            st.setInt(4, lineaPedido.getItem().getIdItem());
            
            st.executeUpdate();

            st.close();
            con.close();
        } catch (SQLException ex) {
            System.err.println("Error en metodo guardaLineaPedido: " + ex);
        }
	}
	
}
