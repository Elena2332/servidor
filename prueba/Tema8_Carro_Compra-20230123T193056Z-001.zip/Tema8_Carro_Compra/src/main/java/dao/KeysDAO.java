package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;

import beans.Cliente;

public class KeysDAO {
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/tienda?zeroDateTimeBehavior=CONVERT_TO_NULL";
    private static final String USER = "root";
    private static final String PASS = "";
    private static BasicDataSource dataSource;

    public KeysDAO() {
        //Creamos el pool de conexiones
        dataSource = new BasicDataSource();
        dataSource.setDriverClassName(DRIVER);
        dataSource.setUrl(URL);
        dataSource.setUsername(USER);
        dataSource.setPassword(PASS);
        //Indicamos el tama�o del pool de conexiones
        dataSource.setInitialSize(50);
    }
    
	/*
	 * Recibe un nombre de tabla y nos devuelva el siguiente id disponible en dicha tabla (1 si a�n
	 * no tiene tuplas, 1+ del mayor id existente en caso contrario)
	 */
	public int siguienteId(String nombreTabla) {
		int maxId = 0;
		String sql = "SELECT MAX(id) 'id' FROM " + nombreTabla;
		try {
            Connection con = dataSource.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                maxId = rs.getInt("id");
            }
            rs.close();
            st.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(KeysDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
		
		if (maxId == 0) {
			return 1;
		} else {
			maxId++;
			return maxId;
		}
	
	}
	
}
